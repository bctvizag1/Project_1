# Project_1
this is orcale data push to customer dailing server in conference hall
