const oracle = require('../models/db');
const sqlquery = require('../models/query').sqlquery;
const itpcQuery = require('../models/query').itpcQuery;

exports.default = (req, res) =>{
    console.log('fired index default');
    res.render('index', { title: 'BSNL Visakhapatnam' });
}

exports.jobStatus = (req,res) =>{
    const sql = sqlquery.Jobstatus; 
    oracle.queryObject(sql,{},{}).then(result => {
        
        res.render( 'JobStatus', {data:result})
    })
}

exports.faultDaily = (req,res) =>{
    const sql = itpcQuery.dailyFaults; 

    console.log("Displayed: Faults");

    oracle.queryObject(sql,{},{},'itpc').then(result => {        
        res.render( 'test', {
            data:result,
            title:"CDR Faults"
                        })
    })
}

exports.wkg_lines = (req,res) =>{

    const sql = sqlquery.wkg_lines;
   
    oracle.queryObject(sql,{},{}).then(result => {        
        res.json({data:result.rows})
    })
}