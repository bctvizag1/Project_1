const express = require('express');
const router = express.Router();

const contrl = require('./controllers/page-controller')

router.get('/',contrl.default);

router.get('/Jobstatus', contrl.jobStatus);
router.get('/faults', contrl.faultDaily);
router.get('/wkg_lines',contrl.wkg_lines);
module.exports = router


